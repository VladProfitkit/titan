<?
$sSectionName = "Сотрудники";
$arDirProperties = Array(

);
?>