<?
$sSectionName = "О компании";
$arDirProperties = Array(
);
?>