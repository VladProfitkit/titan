<?
$sSectionName = "Новости";
$arDirProperties = Array(
   "HIDE_LEFT_BLOCK" => "Y"
);
?>