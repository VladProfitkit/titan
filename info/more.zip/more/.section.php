<?
$sSectionName = "Возможности";
$arDirProperties = Array(

);
?>